(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f1d3f032._.js",
  "static/chunks/1dff6_next_dist_compiled_react-dom_987ad27f._.js",
  "static/chunks/1dff6_next_dist_compiled_react-server-dom-turbopack_b69c1d6b._.js",
  "static/chunks/1dff6_next_dist_compiled_next-devtools_index_b10aad90.js",
  "static/chunks/1dff6_next_dist_compiled_c5f28bd9._.js",
  "static/chunks/1dff6_next_dist_client_e3c2bcb2._.js",
  "static/chunks/1dff6_next_dist_4512f89c._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
