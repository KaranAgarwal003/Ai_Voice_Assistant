"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Bot, FileAudio, FileText, Paperclip, Send, User, X } from "lucide-react"
import type React from "react"
import { useEffect, useRef, useState } from "react"

type Message = {
  id: string
  role: "user" | "assistant"
  content: string
  file?: {
    name: string
    type: string
  }
}

export function TextAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I'm your AI assistant. How can I help you today?",
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if ((!input.trim() && !uploadedFile) || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input || "Uploaded a file",
      ...(uploadedFile && {
        file: {
          name: uploadedFile.name,
          type: uploadedFile.type,
        },
      }),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setUploadedFile(null)
    if (fileInputRef.current) fileInputRef.current.value = ""
    setIsLoading(true)

    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: userMessage.file
          ? `I received your ${userMessage.file.type.includes("pdf") ? "PDF" : "audio"} file "${userMessage.file.name}". In a production app, I would analyze this using AI.`
          : `I received your message: "${userMessage.content}". This is a demo response.`,
      }
      setMessages((prev) => [...prev, assistantMessage])
      setIsLoading(false)
    }, 1000)
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.type.startsWith("audio/") || file.type === "application/pdf") {
      setUploadedFile(file)
    }
  }

  const removeUploadedFile = () => {
    setUploadedFile(null)
    if (fileInputRef.current) fileInputRef.current.value = ""
  }

  return (
    <Card className="flex flex-col h-[600px]
                     bg-black/40 backdrop-blur-md
                     border border-white/10
                     rounded-2xl shadow-xl">
      
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {message.role === "assistant" && (
              <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center">
                <Bot className="w-5 h-5 text-gray-300" />
              </div>
            )}

            <div
              className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-md
                ${
                  message.role === "user"
                    ? "bg-blue-600 text-white"
                    : "bg-zinc-900/80 text-gray-100 backdrop-blur border border-white/10"
                }`}
            >
              {message.file && (
                <div className="mb-2 p-2 rounded-lg bg-black/30 flex items-center gap-2">
                  {message.file.type.includes("pdf") ? (
                    <FileText className="w-4 h-4" />
                  ) : (
                    <FileAudio className="w-4 h-4" />
                  )}
                  <span className="text-xs truncate">{message.file.name}</span>
                </div>
              )}
              {message.content}
            </div>

            {message.role === "user" && (
              <div className="w-8 h-8 rounded-full bg-zinc-700 flex items-center justify-center">
                <User className="w-5 h-5 text-gray-300" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-3 justify-start">
            <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center">
              <Bot className="w-5 h-5 text-gray-300" />
            </div>
            <div className="bg-zinc-900/80 rounded-2xl px-4 py-3 flex gap-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:0.2s]" />
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-white/10 bg-black/30">
        {uploadedFile && (
          <div className="mb-3 p-2 rounded-lg bg-zinc-900 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              {uploadedFile.type.includes("pdf") ? (
                <FileText className="w-4 h-4 text-blue-400" />
              ) : (
                <FileAudio className="w-4 h-4 text-blue-400" />
              )}
              <span className="text-sm truncate text-gray-300">{uploadedFile.name}</span>
            </div>
            <Button variant="ghost" size="icon" type="button" onClick={removeUploadedFile}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        )}

        <div className="flex gap-2">
          <Button type="button" variant="ghost" size="icon" onClick={() => fileInputRef.current?.click()}>
            <Paperclip className="w-4 h-4" />
          </Button>

          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*,application/pdf"
            onChange={handleFileUpload}
            className="hidden"
          />

          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask something..."
            className="flex-1 bg-zinc-900 border border-white/10 text-gray-100"
            disabled={isLoading}
          />

          <Button type="submit" size="icon" disabled={isLoading || (!input.trim() && !uploadedFile)}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </form>
    </Card>
  )
}
