"use client"

import { TextAssistant } from "@/components/text-assistant"

export default function Page() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4
                    bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800">
      
      <div className="w-full max-w-4xl rounded-2xl
                      bg-black/40 backdrop-blur-md
                      shadow-2xl border border-white/10 p-6 md:p-8">
        
        <header className="text-center mb-10">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-white">
            Smart Voice AI Assistant
          </h1>

          <p className="mt-3 text-gray-400 text-lg">
            Voice-enabled AI for chat, speech, and document interaction
          </p>
        </header>

        <TextAssistant />
      </div>
    </div>
  )
}
